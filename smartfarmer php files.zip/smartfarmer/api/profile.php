<?php
    include("../connection.php");
    
    // Retrieves the 'id' value from the POST request.
    $id = $_POST["id"];

    // Constructs an SQL query to select all columns from the 'users' table where the 'id' matches the provided id.
    $sql = "SELECT * FROM users WHERE id = $id";
    
    // Executes the query and stores the result in $result.
    $result = $conn->query($sql);
    
    if(mysqli_num_rows($result) > 0)
    {
        $row = mysqli_fetch_assoc($result);
        $tarray = array();
        $tarray = $row;
        $tarray["status"] = 'success';
        array_push($tarray);
    }
    else
    {
        $tarray = array();
        $tarray["status"] = 'failed';
        array_push($tarray);
    }
    
    header('Content-Type: application/json');
    echo json_encode($tarray);
?>

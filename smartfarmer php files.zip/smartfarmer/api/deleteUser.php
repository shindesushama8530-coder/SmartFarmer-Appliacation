<?php
header('Content-Type: application/json');
include("../connection.php");

// Check if the connection to the database was successful.
if ($conn->connect_error) {
    // If the connection failed, terminate the script and output an error message.
    die("Connection failed: " . $conn->connect_error);
}

// Debugging: Log incoming POST request data to the server's error log.
error_log(print_r($_POST, true));

// Check if the request method is POST.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (isset($_POST['id']) && !empty($_POST['id'])) // Check if the 'id' parameter is set and not empty in the POST request.
    {
        $id = $_POST['id'];
        $sql = "DELETE FROM users WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);

        // Execute the prepared statement.
        if ($stmt->execute())  // If the execution was successful, output a JSON response indicating success.
        {
            echo json_encode(["success" => true, "message" => "User deleted successfully"]);
        } 
        else // If there was an error during execution, output a JSON response indicating failure.
        {
            echo json_encode(["success" => false, "message" => "Error deleting user"]);
        }
    } 
    else  // If the 'id' parameter is not set or is empty, output a JSON response indicating invalid parameters.
    {
        echo json_encode(["success" => false, "message" => "Invalid parameters"]);
    }
}
 else  // If the request method is not POST, output a JSON response indicating an invalid request method.
 {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
 }

$conn->close();
?>

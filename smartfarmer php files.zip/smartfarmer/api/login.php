<?php
    include("../connection.php");

    // Checks if the POST request contains an 'email' field.
    if(isset($_POST['email']))
    {
        // Retrieves the email and password from the POST request.
        $email = $_POST['email'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM users WHERE  email = '$email' AND password = '$password'";
        $users = $conn->query($sql); // Executes the query and stores the result in $users.

        // Checks if any rows were returned by the query (i.e., if a user was found).
        if(mysqli_num_rows($users) > 0) // this condition checks the number of rows that hold by user array if it is greater than 0 then it access first row
        {
            $row = mysqli_fetch_assoc($users); // Fetches the first row of the result as an associative array.
            $tarray = array();
            $tarray["status"] = 'success'; 
		    $tarray["id"] = $row['id']; 
            $tarray["name"] = $row['name']; 
            $tarray["mobileno"] = $row['mobileno']; 
            $tarray["email"] = $row['email']; 
            $tarray["usertype"] = 'user'; 
            array_push($tarray); 
        }
        // If the email and password match the admin credentials.
        else if($email == "admin@gmail.com" && $password=="123")
        {
            $tarray = array(); 
            $tarray["status"] = 'success'; 
            $tarray["id"] = "1"; 
            $tarray["usertype"] = "admin"; 
            $tarray["name"] = "Admin"; 
            $tarray["mobileno"] = ""; 
            $tarray["email"] = "admin@gmail.com"; 
            array_push($tarray); 
        }
        // If no matching user is found and the credentials are not admin credentials.
        else{
            $tarray = array(); 
            $tarray["status"] = 'failed'; 
            array_push($tarray); 
        }
    }
    
    // Sets the content type of the response to JSON.
    header('Content-Type: application/json');
    // Converts the $tarray array to a JSON string and sends it as the response.
	echo json_encode($tarray);
?>

<?php
    include("../connection.php");   

    // Checks if the POST request contains a 'name' field.
    if(isset($_POST['name']))
    {
        // Retrieves the 'id', 'name', 'mobileno', 'email', and 'password' values from the POST request.
        $id = $_POST["id"];
        $name = $_POST["name"];
        $mobileno = $_POST["mobileno"];
        $email = $_POST["email"];
        $password = $_POST["password"];

        // Constructs an SQL query to update the user's details in the 'users' table where the 'id' matches the provided id.
        $sql = "UPDATE users SET name='$name', email='$email', mobileno='$mobileno', ";
        $sql .= "password='$password' WHERE id = $id";
        $result  = mysqli_query($conn, $sql); 
        $tarray = array();

        // Checks if the query execution was successful.
        if(!$result)
        {
            $tarray["status"] = 'failed';
            array_push($tarray); 
        }
        else
        {
            $tarray["status"] = 'success';
            array_push($tarray);
        }
    }
    else
    {
        // If the 'name' field is not set in the POST request, sets the status to 'failed'.
        $tarray["status"] = 'failed';
        array_push($tarray); 
    }
    
    header('Content-Type: application/json'); 
    echo json_encode($tarray);
?>

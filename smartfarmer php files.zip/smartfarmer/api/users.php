<?php
    include("../connection.php");
    $sql = "SELECT * FROM users";
    $result = mysqli_query($conn, $sql);
    $dataarray = array();
    while($row = mysqli_fetch_assoc($result))    // Loops through each row in the result set.
    {
        $tarray = array();
		$tarray["status"] = 'success';
		$tarray = $row;		        // Overwrites $tarray with the current row's data, losing the previous "status" key.
		array_push($dataarray, $tarray);    // Adds the current row's data to the $dataarray.
    }
    header('Content-Type: application/json');
	echo json_encode(array("data"=>$dataarray));
    
?>
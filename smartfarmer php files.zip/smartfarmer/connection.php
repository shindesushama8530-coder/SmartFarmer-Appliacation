<?php
$server="localhost";//host_name
$username="root";//host_username
$password="";//host_password
$dbname="smartfarmer";//database_name
$conn=mysqli_connect($server,$username,$password,$dbname);

?>


package com.example.smartfarmer.user;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartfarmer.R;
import com.example.smartfarmer.adapters.Product;
import com.example.smartfarmer.adapters.ProductAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class ProductListActivity extends AppCompatActivity {

    private static final String TAG = "ProductListActivity";

    private RecyclerView recyclerView;
    private ArrayList<Product> productList;
    private ProductAdapter productAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);

        recyclerView = findViewById(R.id.recyclerViewProducts);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        productList = new ArrayList<>();

        fetchProducts();
    }

    private void fetchProducts() {
        class FetchProductsTask extends AsyncTask<Void, Void, String> {
            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL("http://192.168.150.227/smartfarmer/get_products.php");
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));

                    StringBuilder result = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }

                    reader.close();
                    httpURLConnection.disconnect();
                    return result.toString();
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            protected void onPostExecute(String s) {
                if (s != null) {
                    Log.d(TAG, "JSON Response: " + s);
                    try {
                        JSONArray jsonArray = new JSONArray(s);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            Product product = new Product(
                                    jsonObject.getInt("id"),
                                    jsonObject.getString("name"),
                                    jsonObject.getString("description"),
                                    jsonObject.getDouble("price")
                            );
                            Log.d(TAG, "Parsed Product: " + product.toString());
                            productList.add(product);
                        }

                        productAdapter = new ProductAdapter(ProductListActivity.this, productList);
                        recyclerView.setAdapter(productAdapter);

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(ProductListActivity.this, "Error parsing JSON data", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ProductListActivity.this, "Failed to fetch data from server", Toast.LENGTH_SHORT).show();
                }
            }
        }

        FetchProductsTask fetchProductsTask = new FetchProductsTask();
        fetchProductsTask.execute();
    }
}

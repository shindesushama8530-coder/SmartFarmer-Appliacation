package com.example.smartfarmer.user;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.smartfarmer.R;

public class VideosActivity extends AppCompatActivity {

    TextView link1,link2,link3,link4,link5,link6,link7,link8,link9;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_videos);

        link1=findViewById(R.id.link1);
        link2=findViewById(R.id.link2);
        link3=findViewById(R.id.link3);
        link4=findViewById(R.id.link4);
        link5=findViewById(R.id.link5);
        link6=findViewById(R.id.link6);
        link7=findViewById(R.id.link7);
        link8=findViewById(R.id.link8);
        link9=findViewById(R.id.link9);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        link1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://youtu.be/8Cda6QTnfbY?si=PsNKGRCliCLJSxj4");
            }

        });
        link2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://youtu.be/0WR4BeFcLks?si=KsSWPgFY6oNZMSZ6");
            }

        });
        link3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://youtube.com/playlist?list=PLhSkX0eBPxupX-j-ZaMhr1kGsStDkil9c&si=NqT525UqNikdjkL3");
            }

        });
        link4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://youtu.be/g0wkT3mf80U?si=UdNp-7aA1RI1evMk");
            }

        });
        link5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://youtu.be/ijofn-u9Ctw?si=czBR9Cp4vHTPGhMc");
            }

        });
        link6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://youtu.be/jOv9JGGPhoQ?si=twlqR9Q1DLeVNOOc");
            }

        });
        link7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://youtu.be/xFqecEtdGZ0?si=NemvW18ghhtGdKzn");
            }

        });
        link8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://youtu.be/wougJaN_Ha0?si=UkAdAybjbdgooIJf");
            }

        });
        link9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://youtu.be/_tijHjup-gM?si=IhI11qOInTG-J14C");
            }

        });

    }

    private void gotoUrl(String s) {
        Uri uri=Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }
}
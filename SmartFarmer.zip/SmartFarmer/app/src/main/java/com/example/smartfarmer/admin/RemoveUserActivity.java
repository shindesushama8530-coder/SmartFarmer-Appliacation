package com.example.smartfarmer.admin;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.smartfarmer.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RemoveUserActivity extends AppCompatActivity {

    private EditText userIdEditText;
    private Button removeUserButton;

    private static final String DELETE_USER_URL = "http://192.168.150.227/smartfarmer/api/deleteUser.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_user);

        userIdEditText = findViewById(R.id.editTextUserId);
        removeUserButton = findViewById(R.id.buttonRemoveUser);

        removeUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userIdStr = userIdEditText.getText().toString();
                if (!userIdStr.isEmpty()) {
                    int userId = Integer.parseInt(userIdStr);
                    removeUser(userId);
                } else {
                    Toast.makeText(RemoveUserActivity.this, "Please enter a user ID", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void removeUser(final int id) {
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, DELETE_USER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("RemoveUserActivity", "Response: " + response); // Log the raw response

                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            String message = jsonResponse.getString("message");
                            Toast.makeText(RemoveUserActivity.this, message, Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(RemoveUserActivity.this, "Error parsing response", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(RemoveUserActivity.this, "An error occurred", Toast.LENGTH_SHORT).show();
                Log.e("RemoveUserActivity", "onErrorResponse: ", error);

                // Enhanced error logging
                if (error.networkResponse != null) {
                    Log.e("RemoveUserActivity", "Status Code: " + error.networkResponse.statusCode);
                    try {
                        String body = new String(error.networkResponse.data, "UTF-8");
                        Log.e("RemoveUserActivity", "Response Body: " + body);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("id", String.valueOf(id));
                return params;
            }
        };
        queue.add(stringRequest);
    }
}

package com.example.smartfarmer.adapters;

public class User {

    public String id="";
    public String name="";
    public String email="";
    public String mobileno="";
}
